bl_info = {
    "name": "Blender AI Companion Bridge",
    "author": "Antigravity Assistant",
    "version": (1, 2, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Companion · Chuột phải vào nút bất kỳ > Giải thích (Companion)",
    "description": "Bridges real-time Blender state & tool inspector to Desktop Companion App",
    "category": "Development",
}

import bpy
import json
import socket
import threading
import time
import fnmatch
import gettext

_socket_client = None
_is_connected = False
_worker_thread = None
_stop_event = threading.Event()
_last_sent_hash = None
_last_drawn_connected = None
_op_cache = {}

HOST = "127.0.0.1"
PORT = 28282


# ----------------------------------------------------
# Tra cứu: tiếng Việt (kho dịch có sẵn của Blender), phím tắt, link hướng dẫn chính thức
# ----------------------------------------------------
_vi = None


def vi(text, ctx=None):
    """Dịch sang tiếng Việt bằng kho dịch Blender cài sẵn (không phụ thuộc ngôn ngữ giao diện đang chọn)."""
    global _vi
    if not text:
        return text
    if _vi is None:
        try:
            _vi = gettext.translation("blender", localedir=bpy.utils.system_resource('DATAFILES', path="locale"), languages=["vi"])
        except Exception:
            _vi = False
    if not _vi:
        return text
    try:
        for c in ([ctx] if ctx else []) + ["Operator", "*"]:
            out = _vi.pgettext(c, text) if c != "*" else _vi.gettext(text)
            if out != text:
                return out
    except Exception:
        pass
    return text


def py_idname(bl_idname):
    """MESH_OT_extrude_region -> mesh.extrude_region"""
    if "_OT_" in bl_idname:
        mod, fn = bl_idname.split("_OT_", 1)
        return f"{mod.lower()}.{fn}"
    return bl_idname


def shortcut_for(py_id):
    try:
        kc = bpy.context.window_manager.keyconfigs.user
        for km in kc.keymaps:
            for kmi in km.keymap_items:
                if kmi.idname == py_id and kmi.active and kmi.type not in {'NONE'}:
                    return f"{kmi.to_string()}  ({km.name})"
    except Exception:
        pass
    return ""


def manual_url(doc_id):
    doc_id = doc_id.lower()
    try:
        for prefix, mapping in bpy.utils.manual_map():
            for pattern, suffix in mapping:
                if fnmatch.fnmatchcase(doc_id, pattern):
                    return prefix.replace("/manual/en/", "/manual/vi/") + suffix
    except Exception:
        pass
    return ""


def operator_info(bl_idname, rna=None, source="auto"):
    py_id = py_idname(bl_idname)
    key = (py_id, source)
    if key in _op_cache:
        return dict(_op_cache[key])
    name = desc = ""
    try:
        if rna is None:
            mod, fn = py_id.split(".", 1)
            rna = getattr(getattr(bpy.ops, mod), fn).get_rna_type()
        name, desc = rna.name, rna.description
    except Exception:
        pass
    info = {
        "kind": "operator", "source": source,
        "idname": bl_idname, "python": f"bpy.ops.{py_id}",
        "name": name or py_id, "name_vi": vi(name, "Operator"),
        "description": desc, "description_vi": vi(desc),
        "shortcut": shortcut_for(py_id),
        "manual_url": manual_url(f"bpy.ops.{py_id}"),
    }
    _op_cache[key] = info
    return dict(info)


_SKIP_PROPS = {"rna_type", "event_history", "start_mouse"}
# lệnh thường gặp theo chế độ — để đoán lệnh đứng sau công cụ khi keymap không có
_MODE_OPS = {"SCULPT": ("sculpt", "paint", "mesh", "transform", "object", "view3d"),
             "EDIT_MESH": ("mesh", "transform", "view3d"), "OBJECT": ("object", "transform", "view3d")}


def _prop_info(p, value=None):
    d = {"id": p.identifier, "type": p.type, "name": p.name, "name_vi": vi(p.name),
         "description": p.description, "description_vi": vi(p.description)}
    if p.type == 'ENUM':
        d["items"] = [{"id": e.identifier, "name": e.name, "name_vi": vi(e.name),
                       "description": e.description, "description_vi": vi(e.description)} for e in p.enum_items]
    if value is not None:
        try:
            if isinstance(value, float):
                d["value"] = round(value, 3)
            elif isinstance(value, (str, bool, int)):
                d["value"] = value
            elif isinstance(value, set):
                d["value"] = sorted(value)
            else:
                d["value"] = [round(v, 3) if isinstance(v, float) else v for v in value]
        except Exception:
            d["value"] = str(value)
    return d


def _options_of(rna, values=None):
    out = []
    for p in rna.properties:
        if p.identifier in _SKIP_PROPS or p.type in {'COLLECTION', 'POINTER'} or getattr(p, "is_hidden", False):
            continue
        out.append(_prop_info(p, getattr(values, p.identifier, None) if values is not None else None))
    return out


def _tool_operator(context, td):
    """Lệnh (operator) đứng sau công cụ: ưu tiên keymap "3D View Tool: ..., <tên>", không có thì đoán theo tên + chế độ."""
    try:
        for kc in (context.window_manager.keyconfigs.active, context.window_manager.keyconfigs.default):
            for km in kc.keymaps:
                if km.name.startswith("3D View Tool") and (km.name.endswith(", " + td.label) or km.name.endswith(": " + td.label)):
                    for kmi in km.keymap_items:
                        if kmi.idname:
                            return kmi.idname
    except Exception:
        pass
    short = td.idname.split(".")[-1]
    for mod in _MODE_OPS.get(context.mode, ("object", "mesh", "transform", "view3d")):
        try:
            getattr(getattr(bpy.ops, mod), short).get_rna_type()
            return f"{mod}.{short}"
        except Exception:
            continue
    return ""


def tool_info(context):
    """Công cụ đang chọn trên thanh Toolbar: là gì + các tuỳ chọn (kèm giá trị hiện tại)."""
    try:
        from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
        tool = context.workspace.tools.from_space_view3d_mode(context.mode, create=False)
        if tool is None:
            return None
        cls = ToolSelectPanelHelper._tool_class_from_space_type('VIEW_3D')
        td = next((t for t in ToolSelectPanelHelper._tools_flatten(cls.tools_from_context(context))
                   if t is not None and t.idname == tool.idname), None)
    except Exception as e:
        print("[Companion Bridge] tool_info:", e)
        return None
    label = td.label if td else tool.idname.split(".")[-1].replace("_", " ").title()
    desc = td.description if td and isinstance(td.description, str) else ""
    info = {"kind": "tool", "source": "auto", "idname": tool.idname, "name": label, "name_vi": vi(label),
            "description": desc, "description_vi": vi(desc), "options": [], "python": "", "shortcut": "", "manual_url": ""}

    # Cọ điêu khắc / vẽ: giải thích loại cọ + vài tuỳ chọn chính
    paint = {"SCULPT": "sculpt", "PAINT_TEXTURE": "image_paint", "PAINT_VERTEX": "vertex_paint", "PAINT_WEIGHT": "weight_paint"}.get(context.mode)
    if tool.idname.startswith(("builtin.brush", "builtin_brush")) and paint:
        brush = getattr(getattr(context.tool_settings, paint, None), "brush", None)
        if brush is not None:
            info["name"], info["name_vi"] = f"Cọ: {brush.name}", f"Cọ: {vi(brush.name)}"
            for key in ("sculpt_brush_type", "image_brush_type", "vertex_brush_type", "weight_brush_type"):
                if hasattr(brush, key):
                    p = brush.bl_rna.properties[key]
                    item = next((e for e in p.enum_items if e.identifier == getattr(brush, key)), None)
                    if item:
                        info["description"], info["description_vi"] = item.description, vi(item.description)
                    break
            for key in ("size", "strength", "direction", "hardness", "auto_smooth_factor", "normal_radius_factor", "use_frontface"):
                if key in brush.bl_rna.properties:
                    info["options"].append(_prop_info(brush.bl_rna.properties[key], getattr(brush, key)))
            info["manual_url"] = manual_url("bpy.types.brush")
        return info

    op = _tool_operator(context, td) if td else ""
    if op:
        info["python"] = f"bpy.ops.{op}"
        try:
            mod, fn = op.split(".", 1)
            rna = getattr(getattr(bpy.ops, mod), fn).get_rna_type()
            if not info["description"]:
                info["description"], info["description_vi"] = rna.description, vi(rna.description)
            try:
                values = tool.operator_properties(op)
            except Exception:
                values = None
            info["options"] = _options_of(rna, values)
        except Exception:
            pass
        info["manual_url"] = manual_url(f"bpy.ops.{op}")
        info["shortcut"] = shortcut_for(op)
    return info


def describe_button(context):
    """Nút / mục menu vừa bấm chuột phải: là lệnh (operator) hay thuộc tính (property)?"""
    op = getattr(context, "button_operator", None)
    if op is not None:
        return operator_info(op.bl_rna.identifier, source="button")
    prop = getattr(context, "button_prop", None)
    ptr = getattr(context, "button_pointer", None)
    if prop is not None:
        owner = ptr.bl_rna.identifier if ptr is not None else ""
        doc = f"bpy.types.{owner}.{prop.identifier}" if owner else ""
        return {
            "kind": "property", "source": "button",
            "idname": prop.identifier, "python": doc,
            "owner": owner, "owner_vi": vi(ptr.bl_rna.name) if ptr is not None else "",
            "name": prop.name, "name_vi": vi(prop.name),
            "description": prop.description, "description_vi": vi(prop.description),
            "shortcut": "", "manual_url": manual_url(doc) if doc else "",
            "items": _prop_info(prop).get("items", []),
            "value": _prop_info(prop, getattr(ptr, prop.identifier, None)).get("value") if ptr is not None else None,
        }
    return None


# ----------------------------------------------------
# Trạng thái Blender gửi sang app
# ----------------------------------------------------
def _view3d_override():
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == 'VIEW_3D':
                    region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                    return {"window": win, "screen": win.screen, "area": area, "region": region}
    except Exception:
        pass
    return None


def get_blender_state():
    ov = _view3d_override()
    if ov:
        with bpy.context.temp_override(**ov):
            return _blender_state(bpy.context)
    return _blender_state(bpy.context)


def _blender_state(context):
    mode = getattr(context, "mode", "UNKNOWN")
    active_obj = context.active_object

    state = {
        "timestamp": time.time(),
        "mode": mode,
        "active_object": None,
        "mesh_stats": None,
        "warnings": [],
        "active_tool": "builtin.select_box",
        "last_operator": None,
        "modifiers": [],
        "tool_info": None,
    }

    try:
        tool = context.workspace.tools.from_space_view3d_mode(context.mode, create=False)
        if tool:
            state["active_tool"] = tool.idname
            state["tool_info"] = tool_info(context)
    except Exception:
        pass

    # Lệnh vừa thực hiện (kèm tên/mô tả tiếng Việt + phím tắt) -> app tự giải thích
    try:
        wm = context.window_manager
        if len(wm.operators) > 0:
            last_op = wm.operators[-1]
            state["last_operator"] = operator_info(last_op.bl_idname)   # tra theo tên lệnh (bl_rna của phiên bản lệnh là kiểu chung "Operator")
    except Exception:
        pass

    if active_obj:
        scale = [round(v, 4) for v in active_obj.scale]
        state["active_object"] = {
            "name": active_obj.name,
            "type": active_obj.type,
            "scale": scale,
            "rotation": [round(v, 4) for v in active_obj.rotation_euler],
            "location": [round(v, 4) for v in active_obj.location],
            "visible": active_obj.visible_get(),
        }

        if any(abs(s - 1.0) > 0.001 for s in scale):
            state["warnings"].append({
                "id": "UNAPPLIED_SCALE",
                "level": "warning",
                "message": f"Scale chưa được Apply ({scale[0]}, {scale[1]}, {scale[2]}). Có thể làm sai lệch Bevel & Modifiers!",
                "shortcut": "Ctrl + A > Apply Scale"
            })

        state["modifiers"] = [
            {"name": mod.name, "type": mod.type, "show_viewport": mod.show_viewport}
            for mod in active_obj.modifiers
        ]

        if active_obj.type == 'MESH' and active_obj.data:
            mesh = active_obj.data
            stats = {
                "total_vertices": len(mesh.vertices),
                "total_edges": len(mesh.edges),
                "total_faces": len(mesh.polygons),
                "selected_vertices": 0,
                "selected_edges": 0,
                "selected_faces": 0,
                "ngon_count": 0
            }

            if mode == 'EDIT_MESH':
                try:
                    import bmesh
                    bm = bmesh.from_edit_mesh(mesh)
                    stats["selected_vertices"] = sum(1 for v in bm.verts if v.select)
                    stats["selected_edges"] = sum(1 for e in bm.edges if e.select)
                    stats["selected_faces"] = sum(1 for f in bm.faces if f.select)
                    ngon_faces = sum(1 for f in bm.faces if len(f.verts) > 4)
                    stats["ngon_count"] = ngon_faces
                    if ngon_faces > 0:
                        state["warnings"].append({
                            "id": "NGONS_DETECTED",
                            "level": "info",
                            "message": f"Phát hiện {ngon_faces} mặt N-gon (> 4 cạnh). Chú ý khi dùng Subsurf!",
                            "shortcut": "Chọn mặt > Ctrl + T hoặc J"
                        })
                except Exception:
                    pass

            state["mesh_stats"] = stats

    return state


# ----------------------------------------------------
# Kết nối TCP tới Companion App (app là server, add-on tự kết nối lại khi app mở sau)
# ----------------------------------------------------
def client_worker():
    global _socket_client, _is_connected

    while not _stop_event.is_set():
        if not _is_connected:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(2.0)
                s.connect((HOST, PORT))
                _socket_client = s
                _is_connected = True
                print(f"[Companion Bridge] Connected to Companion App on {HOST}:{PORT}")
            except Exception:
                _is_connected = False
                _socket_client = None
                time.sleep(2.0)
                continue

        try:
            _socket_client.settimeout(0.5)
            data = _socket_client.recv(4096)
            if data:
                for line in data.decode("utf-8", "ignore").splitlines():
                    line = line.strip()
                    if line:
                        try:
                            handle_incoming_command(json.loads(line))
                        except json.JSONDecodeError:
                            pass
            else:
                _drop_connection()
        except socket.timeout:
            pass
        except Exception:
            _drop_connection()
            time.sleep(1.0)


def _drop_connection():
    global _socket_client, _is_connected, _last_sent_hash
    _is_connected = False
    _last_sent_hash = None          # kết nối lại thì gửi lại toàn bộ trạng thái
    if _socket_client:
        try:
            _socket_client.close()
        except Exception:
            pass
    _socket_client = None


def handle_incoming_command(msg):
    cmd = msg.get("command")
    if cmd == "ping":
        send_data({"event": "pong"})
    elif cmd == "apply_scale":
        def _apply():
            if bpy.context.active_object and bpy.context.mode == 'OBJECT':
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        bpy.app.timers.register(_apply, first_interval=0.01)
    elif cmd == "recalculate_normals":
        def _normals():
            if bpy.context.mode == 'EDIT_MESH':
                bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.app.timers.register(_normals, first_interval=0.01)


def send_data(payload):
    if _is_connected and _socket_client:
        try:
            _socket_client.sendall((json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8"))
            return True
        except Exception:
            _drop_connection()
    return False


def _redraw_panels():
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def sync_timer():
    global _last_sent_hash, _last_drawn_connected
    if _stop_event.is_set():
        return None
    if _last_drawn_connected != _is_connected:      # cập nhật dòng "Status" trong panel ngay khi nối/ngắt
        _last_drawn_connected = _is_connected
        _redraw_panels()
    if _is_connected:
        try:
            state = get_blender_state()
            lo = state["last_operator"]
            state_hash = hash((
                state["mode"], state["active_tool"],
                lo["python"] if lo else "",
                len(bpy.context.window_manager.operators),
                state["active_object"]["name"] if state["active_object"] else "",
                str(state["active_object"]["scale"]) if state["active_object"] else "",
                len(state["warnings"]),
                state["mesh_stats"]["selected_vertices"] if state["mesh_stats"] else 0,
                state["mesh_stats"]["selected_faces"] if state["mesh_stats"] else 0,
                json.dumps([o.get("value") for o in (state["tool_info"] or {}).get("options", [])], default=str),
                (state["tool_info"] or {}).get("name", ""),
            ))
            if state_hash != _last_sent_hash:
                _last_sent_hash = state_hash
                send_data({"event": "state_update", "data": state})
        except Exception as e:
            print("[Companion Bridge] state error:", e)
    return 0.20


def start_bridge():
    global _worker_thread
    _stop_event.clear()
    if _worker_thread is None or not _worker_thread.is_alive():
        _worker_thread = threading.Thread(target=client_worker, daemon=True)
        _worker_thread.start()
    if not bpy.app.timers.is_registered(sync_timer):
        bpy.app.timers.register(sync_timer, first_interval=0.20, persistent=True)


# ----------------------------------------------------
# Operators + UI
# ----------------------------------------------------
class COMPANION_OT_Connect(bpy.types.Operator):
    bl_idname = "companion.connect"
    bl_label = "Connect to Companion"

    def execute(self, context):
        start_bridge()
        self.report({'INFO'}, f"Đang kết nối Companion App (cổng {PORT})...")
        return {'FINISHED'}


class COMPANION_OT_Explain(bpy.types.Operator):
    bl_idname = "companion.explain_button"
    bl_label = "Giải thích (Companion)"
    bl_description = "Gửi nút / mục menu này sang Companion App để xem nó là gì, dùng làm gì, phím tắt"

    def execute(self, context):
        info = describe_button(context)
        if info is None:
            self.report({'WARNING'}, "Mục này là menu con / nhãn, không có lệnh riêng — mở nó ra rồi chuột phải vào lệnh bên trong")
            return {'CANCELLED'}
        sent = send_data({"event": "explain", "data": info})
        text = f"{info['name_vi']}: {info['description_vi'] or info['description']}"
        self.report({'INFO'}, text[:200] + ("" if sent else "   (Companion App chưa mở)"))
        return {'FINISHED'}


class COMPANION_OT_ApplyScale(bpy.types.Operator):
    bl_idname = "companion.apply_scale"
    bl_label = "Quick Apply Scale"

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        self.report({'INFO'}, "Scale Applied Successfully (1.0, 1.0, 1.0)")
        return {'FINISHED'}


class COMPANION_OT_FixNormals(bpy.types.Operator):
    bl_idname = "companion.fix_normals"
    bl_label = "Recalculate Normals"

    def execute(self, context):
        if context.mode != 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        self.report({'INFO'}, "Normals Recalculated (Facing outward)")
        return {'FINISHED'}


class COMPANION_PT_Panel(bpy.types.Panel):
    bl_label = "AI Companion Bridge"
    bl_idname = "COMPANION_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Companion"

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        if _is_connected:
            box.label(text="Đã kết nối Companion App", icon='CHECKMARK')
        else:
            box.label(text="Chưa kết nối — hãy mở Companion App", icon='CANCEL')
            box.operator("companion.connect", icon='PLAY')
        box.label(text=f"Cổng: {PORT}", icon='LINKED')
        layout.label(text="Mẹo: chuột phải vào nút bất kỳ", icon='QUESTION')
        layout.label(text="→ Giải thích (Companion)")

        col = layout.column(heading="Quick Beginner Fixes:", align=True)
        col.operator("companion.apply_scale", icon='OBJECT_DATA', text="Fix: Apply Scale (Ctrl+A)")
        col.operator("companion.fix_normals", icon='NORMALS_FACE', text="Fix: Recalculate Normals (Shift+N)")


# Menu chuột phải trên nút: Blender không định nghĩa sẵn, add-on tự khai báo (rỗng) rồi gắn mục của mình vào.
class WM_MT_button_context(bpy.types.Menu):
    bl_label = ""

    def draw(self, context):
        pass


_own_button_menu = False


def draw_button_context(self, context):
    layout = self.layout
    layout.separator()
    layout.operator(COMPANION_OT_Explain.bl_idname, icon='QUESTION')


classes = (
    COMPANION_OT_Connect,
    COMPANION_OT_Explain,
    COMPANION_OT_ApplyScale,
    COMPANION_OT_FixNormals,
    COMPANION_PT_Panel,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    global _own_button_menu
    if not hasattr(bpy.types, "WM_MT_button_context"):
        bpy.utils.register_class(WM_MT_button_context)
        _own_button_menu = True
    bpy.types.WM_MT_button_context.append(draw_button_context)
    start_bridge()


def unregister():
    _stop_event.set()
    _drop_connection()
    if bpy.app.timers.is_registered(sync_timer):
        bpy.app.timers.unregister(sync_timer)
    global _own_button_menu
    if hasattr(bpy.types, "WM_MT_button_context"):
        bpy.types.WM_MT_button_context.remove(draw_button_context)
        if _own_button_menu and not getattr(bpy.types.WM_MT_button_context, "_dyn_ui_initialize", lambda: [])():
            bpy.utils.unregister_class(bpy.types.WM_MT_button_context)
        _own_button_menu = False
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
